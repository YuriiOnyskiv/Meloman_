var searchData=
[
  ['settings',['Settings',['../class_meloman_1_1_properties_1_1_settings.html',1,'Meloman::Properties']]],
  ['settings_2edesigner_2ecs',['Settings.Designer.cs',['../_settings_8_designer_8cs.html',1,'']]]
];
