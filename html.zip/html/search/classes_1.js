var searchData=
[
  ['resources',['Resources',['../class_meloman_1_1_properties_1_1_resources.html',1,'Meloman::Properties']]]
];
