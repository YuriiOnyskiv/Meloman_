var searchData=
[
  ['resources',['Resources',['../class_meloman_1_1_properties_1_1_resources.html',1,'Meloman::Properties']]],
  ['resources_2edesigner_2ecs',['Resources.Designer.cs',['../_resources_8_designer_8cs.html',1,'']]]
];
